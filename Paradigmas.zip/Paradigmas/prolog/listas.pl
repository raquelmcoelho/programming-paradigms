lista([]).
lista_iguais([a,b,c],[a,b,c]).
concatena([a,b],[c,d],[a,b,c,d]).
iguais([],[]).
iguais([X|Y],[X|Y]).